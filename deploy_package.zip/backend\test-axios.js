import axios from 'axios';
console.log('Axios loaded:', typeof axios);
