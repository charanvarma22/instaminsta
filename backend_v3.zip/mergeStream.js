export function mergeAV() {
    throw new Error("mergeAV not used for Instagram (audio already muxed)");
}
